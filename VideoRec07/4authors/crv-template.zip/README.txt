
To make a sample CVPR paper, copy the contents of this directory somewhere,
and type

 latex egpaper

or 

 pdflatex egpaper

